# Budget-Traveler

Run Site

cd my-react-website
npm start

Run database

cd my-react-website
cd backend
npm start




Run Cors
cd my-react-website

npm run start-cors-proxy
